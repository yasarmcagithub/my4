<?php
require_once('conn.php');
$sql="SELECT * FROM personal_detail";
$run=mysqli_query($conn,$sql);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<style type="text/css">
		*
		{
			margin: 0;
			padding: 0;
		}
		.head
		{
			height: 50px;
			background-color: #3492eb;
		}
		.pd_div
		{
		    background-color: #e7e7e7;
		    height: 50px;
		    display: flex;
		    justify-content: space-between;
		    align-content: center;
		    align-items: center;	   
		}
		a
		{
			 text-decoration: none;
			 background-color: #14c71a;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
		}
		.heading
		{
			margin-left: 20px;
			font-size: 24px;
			font-weight: bold;
		}
		.filter_search
		{
            height: 80px;
            /*background-color: #abdc;*/
            display: flex;
            align-items: center;
            float: right;
            margin-right: 20px;


            /*justify-content: space-between;*/

		}
		.search_right
		{
			/*float: right!important;*/
		}
		.clear
		{
			clear: both;
			display: flex;
			justify-content: center;
		}
		#list 
		{
		  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		  border-collapse: collapse;
		  width: 100%;
        }

        #list td, #list th 
        {
		  border: 1px solid #ddd;
		  padding: 8px;
        }

        #list tr:nth-child(even)
        {
        	background-color: #f2f2f2;
        }

		#list tr:hover 
		{
			background-color: #ddd;
			cursor: pointer;
		}

		#list th 
		{
		  padding-top: 12px;
		  padding-bottom: 12px;
		  text-align: left;
		  background-color: #4CAF50;
		  color: white;
		}
	</style>
</head>
<body>
	<div class="head">
		
	</div>

	<div class="pd_div">
		<p class="heading">Personal Details</p>
		<a href="personal_detail.php">Add User</a>
	</div>

	<div class="filter_search">
		<div class="search_right">
			<input type="text" class="search" name="">
			<button>Search</button>
	     </div>
	</div>

<div class="clear">
	

<table id="list">
  <tr>
				<th><input type="checkbox" name=""></th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>email</th>
				<th>Gender</th>
				<th>Mobile Number</th>
				<th>Adress 1</th>
				<th>Adress 2</th>
				<th>Country</th>
				<th>State</th>
				<th>City</th>
				<th>Pincode</th>
				<th>Edit</th>
				<th>Delete</th>
			</tr>

	 <?php
	 foreach($run as $row) 
	  {
	  ?>
    <tr>
    	<td><input type="checkbox" name=""></td>
	    <td><?php echo $row['first_name']; ?></td>
   		<td><?php echo $row['last_name']; ?></td>
   		<td><?php echo $row['email']; ?></td>  
   		<td><?php echo $row['gender']; ?></td>
   		<td><?php echo $row['mobile_no']; ?></td>
   		<td><?php echo $row['addr1']; ?></td> 
   		<td><?php echo $row['addr2']; ?></td>
   		<td><?php echo $row['country']; ?></td>
   		<td><?php echo $row['state']; ?></td> 
   		<td><?php echo $row['city']; ?></td>
   		<td><?php echo $row['pincode']; ?></td>
   		<td><img src="edit.png" height="20px" width="20px"></td>
   		<td><img src="delete.png" height="20px" width="20px"></td>
    </tr>	
	<?php } ?>
</table> 
 </div> 

</body>
</html>