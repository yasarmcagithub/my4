<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<style type="text/css">
		*
		{
			margin: 0;
			padding: 0;
		}
		.head
		{
			height: 50px;
			background-color: #3492eb;
		}
		.pd_div
		{
		    background-color: #e7e7e7;
		    height: 50px;
		    display: flex;
		    align-content: center;
		    align-items: center;	   
		}
		a
		{
			 margin-left: 1200px;
			 text-decoration: none;
			 background-color: #14c71a;
			 padding: 8px 20px;
			 color: white;
			 border-radius: 20px;
		}
	</style>
</head>
<body>
	<div class="head">
		
	</div>
	<div class="pd_div">
	<a href="personal_detail.php">Add User</a>
	</div>

</body>
</html>