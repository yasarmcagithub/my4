<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<style type="text/css">
		*
		{
			margin: 0;
			padding: 0;
		}
		.head
		{
			height: 50px;
			background-color: #3492eb;
		}
		.pd_div
		{
		    background-color: #e7e7e7;
		    height: 50px;
		    display: flex;
		    justify-content: space-between;
		    align-content: center;
		    align-items: center;	   
		}
		a
		{
			 text-decoration: none;
			 background-color: #14c71a;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
		}
		.heading
		{
			margin-left: 20px;
			font-size: 24px;
			font-weight: bold;
		}
		.filter_search
		{
            height: 80px;
            /*background-color: #abdc;*/
            display: flex;
            align-items: center;
            float: right;
            margin-right: 20px;


            /*justify-content: space-between;*/

		}
		.search_right
		{
			/*float: right!important;*/
		}
		.clear
		{
			clear: both;
			display: flex;
			justify-content: center;
		}
	</style>
</head>
<body>
	<div class="head">
		
	</div>

	<div class="pd_div">
		<p class="heading">Personal Details</p>
		<a href="personal_detail.php">Add User</a>
	</div>

	<div class="filter_search">
		<div class="search_right">
			<input type="text" class="search" name="">
			<button>Search</button>
	     </div>
	</div>

<div class="clear">
	<table>
		<tr>
			<th>First Name</th>
			<th>Last Name</th>
			<th>email</th>
			<th>Gender</th>
			<th>Mobile Number</th>
			<th>Adress 1</th>
			<th>Adress 2</th>
			<th>Country</th>
			<th>State</th>
			<th>city</th>
			<th>pincode</th>
			<th>Edit</th>
			<th>Eelete</th>
		</tr>
		<tr>
			<td>kihju</td>
			<td>jh</td>
			<td>hj</td>
		</tr>
	</table>
</div>

</body>
</html>