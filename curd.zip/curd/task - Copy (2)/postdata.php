<?php
require_once('conn.php');
// if (isset($_POST['submit']))
//    {
    $value=$_POST['values'];  //get array of value from the personal detail page
     // print_r($value);
     // echo $value['fname'];
     //fist we get single value from the array so blow we store the single value to the varable

    $fname=$value['fname'];
    $lname=$value['lname'];
    $email=$value['email'];
    $gender=$value['gender'];
    $mobile=$value['mobile'];
    $address1=$value['address1'];
    $address2=$value['address2'];
    $country=$value['country'];
    $state=$value['state'];
    $city=$value['city'];
    $pincode=$value['pincode'];

    $query = "SELECT * FROM personal_detail WHERE email = '$email'";
    $result=$conn->query($query);
    if(mysqli_num_rows($result) == 0)
    {
   
		    $sql="INSERT INTO personal_detail(first_name,last_name,email,gender,mobile_no,addr1,addr2,country,state,city,pincode)VALUES('$fname','$lname','$email','$gender','$mobile','$address1','$address2','$country','$state','$city','$pincode')";
		   
		    if($conn->query($sql))
		    {
		    	// echo "<p class='sucsusspara'>Insert Data Succsussfully<p>";
		    	echo json_encode(array("status"=>1,"message"=>"Insert Data Succsussfully"));
		        // sleep(3);
		        // header("location: index.php");
		    }
		    else
		    	{
		            // echo $sql;
		            echo json_encode(array("status"=>2,"message"=>"Data not Insert Please Check DB"));
		    	}
	  }
    else
    {
    	// echo "email exixt";
    	 echo json_encode(array("status"=>3,"message"=>"Email Already Exsist"));
    }
   

    // $data=array_values($value);
    // for($i=0;count($array)>$i;$i++)

    // {
    // 	echo $array;
    // }
    // foreach ($data as $key => $datavalues) 
    // {
    // 	echo '"<br>"'.$datavalues.'"<br>"';
    // 	// echo $key;
    // 	// echo "Key=" . $key . ", Value=" . $datavalues"<br>";
    // }

// if (isset($_POST['submit']))

// {
// 	$fname=$_POST['fname'];
// 	echo $fname;
// }





   	// echo $a;
   // }
?>